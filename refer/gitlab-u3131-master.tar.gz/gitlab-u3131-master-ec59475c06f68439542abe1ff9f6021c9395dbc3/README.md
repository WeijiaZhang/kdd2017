# KDD CUP 2017
Task 2

## Task list
- [x] add trivial features
- [x] extract the volume of last two hours as a feature
- [x] xgboost and cross validation 
- [x] try NearestNeighbors
- [ ] add data dependece and update invalid data accordingly

---
**Team**

- [@tecore][tecore]
- [@巴尔干2016][baergan]


[tecore]: https://tianchi.aliyun.com/science/scientistDetail.htm?userId=1095279118908
[baergan]: https://tianchi.aliyun.com/science/scientistDetail.htm?spm=5176.100170.222.4.fxW0P2&userId=1095279120707